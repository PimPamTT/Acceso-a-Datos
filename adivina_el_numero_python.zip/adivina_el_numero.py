# Programa en el que intentas adivinar un número aleatorio

# Importamos la libreria random
import random

# Inicialización y asignación de variables
numero_secreto = random.randint(1, 10)
intentos = 0

# Pintar en consola información y datos
print("INTENTA ADIVINAR EL NÚMERO")
print("Adivina un número entre el 1 y el 10")

# Bucle principal del juego
while True:
    # Solicitar una respuesta al usuario
    respuesta = input("Ingresa tu respuesta: ")

    # Validar si la entra de datos es un numero
    if not respuesta.isdigit():
        print("Cabrón escribe un número")
        continue

    # Convertimos el número en un entero (casting)
    respuesta = int(respuesta)
    intentos += 1

    # Comprobar e ir avisando
    if respuesta < numero_secreto:
        print("Pringado el número es más alto, vuelve a probar tolai")
    elif respuesta > numero_secreto:
        print("Pringado el número es más bajo, vuelve a probar tolai")
    else:
        print(f"Que suerte bro, adivinaste el número en {intentos} intentos")
        break