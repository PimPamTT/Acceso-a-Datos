# Programa en el que intentas adivinar un número aleatorio
# Importamos la libreria random
import random

# Variables de permisos para el bucle condicional
perm1 = False
perm2 = False
perm3 = False

# Inicializamos los valores del juego
num1 = 0
num2 = 0
numero_secreto = 0
lim_intentos = 0
intentos = 0

# Comprobación de que el usuario es majo y escribe bien las cosas
while True:
    if perm1 and perm2 and perm3:
        print("Sabes escribir\n")
        break
    elif perm1 == False:
        num1 = input("Escribe el numero mas bajo que quieras: ")
    elif perm2 == False:
        num2 = input("Escribe el numero mas alto que quieras: ")
    elif perm3 == False:
        lim_intentos = input("Escribe el numero número de intento que quieras: ")

    # Print por que me sale de lo huevos
    # print(num1)
    # print(num2)

    if not num1.isdigit() and perm1 == False:
        print("Cabrón escribe un número")
        continue
    elif num1.isdigit() and perm1 == False:
        print("Eres un bestia")
        perm1 = True
        continue
    elif not num2.isdigit() and perm2 == False:
        print("Cabrón escribe un número")
        continue
    elif num2.isdigit() and perm2 == False:
        print("Eres un maquina")
        perm2 = True
        continue
    elif not lim_intentos.isdigit() and perm3 == False:
        print("Cabrón escribe un número")
        continue
    elif lim_intentos.isdigit() and perm3 == False:
        print("Eres dios")
        perm3 = True
        continue

# Casting al final para evitar errores
num1 = int(num1)
num2 = int(num2)
lim_intentos = int(lim_intentos)

# Inicialización y asignación de variables
# Comprobación de si los numeros son más bajo o altos
if num1 > num2:
    print("Casi cuela crack")
    numero_secreto = random.randint(num2, num1)
elif num1 < num2:
    print("Que majete eres")
    numero_secreto = random.randint(num1, num2)

# Pintar en consola información y datos
print("INTENTA ADIVINAR EL NÚMERO")
print(f"Adivina un número entre el {num1} y el {num2}")

# Bucle principal del juego
while True and intentos < lim_intentos:
    # Solicitar una respuesta al usuario
    respuesta = input("Ingresa tu respuesta: ")

    # Validar si la entra de datos es un numero
    if not respuesta.isdigit():
        print("Cabrón escribe un número")
        continue

    # Convertimos el número en un entero (casting)
    respuesta = int(respuesta)
    intentos += 1

    # Comprobar e ir avisando
    if respuesta < numero_secreto:
        print("Pringado el número es más alto, vuelve a probar tolai")
    elif respuesta > numero_secreto:
        print("Pringado el número es más bajo, vuelve a probar tolai")
    else:
        print(f"Que suerte bro, adivinaste el número en {intentos} intentos")
        break

print("Te pasaste del limite de intentos pendejo")